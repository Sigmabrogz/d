import { useEffect, useState } from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface InactivityWarningProps {
  userProfile?: {
    id: string;
    last_activity_warning: string | null;
  };
}

export const InactivityWarning = ({ userProfile }: InactivityWarningProps) => {
  const [lastActivity, setLastActivity] = useState<Date | null>(null);
  const [daysUntilInactive, setDaysUntilInactive] = useState<number | null>(null);

  useEffect(() => {
    const fetchLastActivity = async () => {
      if (!userProfile?.id) return;

      const { data, error } = await supabase
        .from('tweets')
        .select('created_at')
        .eq('user_id', userProfile.id)
        .order('created_at', { ascending: false })
        .limit(1);

      if (error) {
        console.error('Error fetching last activity:', error);
        return;
      }

      if (data && data.length > 0) {
        const lastTweetDate = new Date(data[0].created_at);
        setLastActivity(lastTweetDate);

        // Calculate days until inactive (3 days from last activity)
        const now = new Date();
        const daysSinceActivity = Math.floor((now.getTime() - lastTweetDate.getTime()) / (1000 * 60 * 60 * 24));
        const remainingDays = 3 - daysSinceActivity;
        setDaysUntilInactive(remainingDays);
      }
    };

    fetchLastActivity();
  }, [userProfile?.id]);

  if (!userProfile) return null;

  const showWarning = daysUntilInactive !== null && daysUntilInactive <= 1;
  const showCountdown = daysUntilInactive !== null && daysUntilInactive <= 2;

  return (
    <div className="space-y-4">
      {showWarning && (
        <Alert variant="destructive" className="bg-red-50 border-red-200">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            Warning: Your account will be removed in {daysUntilInactive} day{daysUntilInactive !== 1 ? 's' : ''} due to inactivity. 
            Please engage with the community to keep your account active.
          </AlertDescription>
        </Alert>
      )}

      {!showWarning && showCountdown && (
        <Alert variant="default" className="bg-yellow-50 border-yellow-200">
          <Clock className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            Your account needs activity within {daysUntilInactive} days to remain active.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Activity Requirements</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-sm text-gray-600">
            To maintain an engaged community, accounts must show activity at least once every 3 days.
            Activity includes:
          </p>
          <ul className="list-disc list-inside text-sm text-gray-600 ml-4">
            <li>Submitting a tweet</li>
            <li>Engaging with other users' tweets</li>
            <li>Following other users</li>
          </ul>
          {lastActivity && (
            <p className="text-sm text-gray-600 mt-4">
              Your last activity was on: {lastActivity.toLocaleDateString()}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};