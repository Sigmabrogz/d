import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Inbox } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const UnengagedTweetsCard = () => {
  const { data: unengagedCount, isLoading } = useQuery({
    queryKey: ['unengagedTweets'],
    queryFn: async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return 0;

        // First get total count of tweets excluding user's own
        const { count: totalCount, error: totalError } = await supabase
          .from('tweets')
          .select('*', { count: 'exact', head: true })
          .neq('user_id', user.id);

        if (totalError) {
          console.error('Error fetching total count:', totalError);
          return 0;
        }

        // Then get count of engaged tweets
        const { count: engagedCount, error: engagedError } = await supabase
          .from('engagements')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', user.id);

        if (engagedError) {
          console.error('Error fetching engaged count:', engagedError);
          return 0;
        }

        // Calculate unengaged count
        const unengaged = (totalCount || 0) - (engagedCount || 0);
        return Math.max(0, unengaged); // Ensure we don't return negative numbers
      } catch (error) {
        console.error('Error in unengaged tweets query:', error);
        return 0;
      }
    },
    refetchInterval: 5000 // Refresh every 5 seconds to keep count updated
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">
          Available Tweets for Engagement
        </CardTitle>
        <Inbox className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">
          {isLoading ? "..." : unengagedCount}
        </div>
        <p className="text-xs text-muted-foreground">
          Tweets waiting for your engagement
        </p>
      </CardContent>
    </Card>
  );
};