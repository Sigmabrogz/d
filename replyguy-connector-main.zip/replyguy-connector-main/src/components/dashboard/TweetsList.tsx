import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield } from "lucide-react";

interface Tweet {
  id: string;
  url: string;
  created_at: string;
  engagement_count: number | null;
}

interface TweetsListProps {
  tweets: Tweet[];
  loadingTweets: boolean;
  onChallenge: (tweetId: string) => void;
}

export const TweetsList = ({ tweets, loadingTweets, onChallenge }: TweetsListProps) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const isNewTweet = (date: string) => {
    const tweetDate = new Date(date);
    const now = new Date();
    const diffInHours = (now.getTime() - tweetDate.getTime()) / (1000 * 60 * 60);
    return diffInHours <= 24; // Consider tweets less than 24 hours old as new
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Submitted Tweets</CardTitle>
      </CardHeader>
      <CardContent>
        {loadingTweets ? (
          <p className="text-center text-muted-foreground py-8">
            Loading tweets...
          </p>
        ) : tweets.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            No tweets have been submitted yet
          </p>
        ) : (
          <div className="space-y-4">
            {tweets.map((tweet) => (
              <div key={tweet.id} className="border rounded-lg p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">
                      {formatDate(tweet.created_at)}
                    </span>
                    {isNewTweet(tweet.created_at) && (
                      <Badge variant="secondary" className="bg-blue-500 text-white">
                        NEW
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">
                      {tweet.engagement_count || 0} engagements
                    </span>
                    {tweet.engagement_count > 0 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onChallenge(tweet.id)}
                        className="flex items-center gap-1"
                      >
                        <Shield className="h-4 w-4" />
                        Challenge
                      </Button>
                    )}
                  </div>
                </div>
                <a
                  href={tweet.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-500 hover:underline break-all"
                >
                  {tweet.url}
                </a>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};