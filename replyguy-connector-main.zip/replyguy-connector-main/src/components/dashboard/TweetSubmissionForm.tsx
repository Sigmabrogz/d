import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface TweetSubmissionFormProps {
  tweetUrl: string;
  loading: boolean;
  dailySubmissionCount: number;
  MAX_DAILY_SUBMISSIONS: number;
  userProfile?: { twitter_handle: string | null };
  onTweetUrlChange: (value: string) => void;
  onSubmit: (e: React.FormEvent) => void;
}

export const TweetSubmissionForm = ({
  tweetUrl,
  loading,
  dailySubmissionCount,
  MAX_DAILY_SUBMISSIONS,
  userProfile,
  onTweetUrlChange,
  onSubmit,
}: TweetSubmissionFormProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Submit Tweet</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="flex gap-4">
            <Input
              type="url"
              placeholder="Paste your tweet URL here"
              value={tweetUrl}
              onChange={(e) => onTweetUrlChange(e.target.value)}
              className="flex-1"
            />
            <Button 
              type="submit" 
              disabled={loading || dailySubmissionCount >= MAX_DAILY_SUBMISSIONS || !userProfile?.twitter_handle}
            >
              {loading ? "Submitting..." : "Submit"}
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            Daily submissions: {dailySubmissionCount}/{MAX_DAILY_SUBMISSIONS}
          </p>
          {!userProfile?.twitter_handle && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Please add your Twitter handle in your profile settings before submitting tweets.
              </AlertDescription>
            </Alert>
          )}
          <Alert variant="default" className="bg-blue-50">
            <AlertDescription>
              You can only submit tweets from your own Twitter handle ({userProfile?.twitter_handle || 'Not set'}).
              Make sure the URL contains your handle.
            </AlertDescription>
          </Alert>
        </form>
      </CardContent>
    </Card>
  );
};