import React from "react";
import { Input } from "@/components/ui/input";

interface ProofUrlFormProps {
  proofUrl: string;
  setProofUrl: (url: string) => void;
}

export function ProofUrlForm({ proofUrl, setProofUrl }: ProofUrlFormProps) {
  return (
    <Input
      placeholder="Paste the URL of your engagement here"
      value={proofUrl}
      onChange={(e) => setProofUrl(e.target.value)}
      required
    />
  );
}