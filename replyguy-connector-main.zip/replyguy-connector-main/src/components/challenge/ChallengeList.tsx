import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield } from "lucide-react";
import { Database } from "@/integrations/supabase/types";

type Profile = Database['public']['Tables']['profiles']['Row'];
type Follow = Database['public']['Tables']['follows']['Row'] & {
  profiles?: Profile | null;
};

export function ChallengeList() {
  const { data: challenges, isLoading } = useQuery({
    queryKey: ['challenges'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const [engagementChallenges, followChallenges] = await Promise.all([
        supabase
          .from('engagements')
          .select('*, tweets(*)')
          .eq('user_id', user.id)
          .eq('challenge_status', 'challenged'),
        
        supabase
          .from('follows')
          .select('*, profiles!follows_following_id_fkey_profiles(*)')
          .eq('follower_id', user.id)
          .eq('challenge_status', 'challenged')
      ]);

      return [
        ...(engagementChallenges.data || []).map(c => ({ ...c, type: 'engagement' as const })),
        ...(followChallenges.data || []).map(c => ({ ...c, type: 'follow' as const }))
      ];
    }
  });

  if (isLoading) {
    return <div>Loading challenges...</div>;
  }

  if (!challenges?.length) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-center text-muted-foreground">
            You have no active challenges
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {challenges.map((challenge) => (
        <Card key={challenge.id}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Shield className="h-5 w-5" />
              {challenge.type === 'engagement' ? 'Tweet Challenge' : 'Follow Challenge'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {challenge.type === 'engagement' && challenge.tweets && (
                <p className="text-sm text-muted-foreground">
                  Tweet URL: <a href={challenge.tweets.url} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{challenge.tweets.url}</a>
                </p>
              )}
              {challenge.type === 'follow' && challenge.profiles && (
                <p className="text-sm text-muted-foreground">
                  Following: {challenge.profiles.full_name || challenge.profiles.username || 'Unknown User'}
                </p>
              )}
              <p className="text-sm text-muted-foreground">
                Status: {challenge.challenge_status}
              </p>
              {challenge.challenge_proof && (
                <p className="text-sm text-muted-foreground">
                  Proof submitted: {challenge.challenge_proof}
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}