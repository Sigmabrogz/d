import React from "react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

interface ProofFileFormProps {
  setProofFile: (file: File | null) => void;
  proofFile: File | null;
}

export function ProofFileForm({ setProofFile, proofFile }: ProofFileFormProps) {
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please upload a file smaller than 5MB",
          variant: "destructive",
        });
        return;
      }
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file",
          variant: "destructive",
        });
        return;
      }
      setProofFile(file);
    }
  };

  return (
    <div className="space-y-2">
      <Input
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        required
      />
      {proofFile && (
        <p className="text-sm text-muted-foreground">
          Selected file: {proofFile.name}
        </p>
      )}
    </div>
  );
}