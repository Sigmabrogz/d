import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Upload, Shield, Link as LinkIcon } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProofUrlForm } from "./challenge/ProofUrlForm";
import { ProofFileForm } from "./challenge/ProofFileForm";

interface ChallengeProofModalProps {
  isOpen: boolean;
  onClose: () => void;
  challengeType: "engagement" | "follow";
  challengeId: string;
}

export function ChallengeProofModal({
  isOpen,
  onClose,
  challengeType,
  challengeId,
}: ChallengeProofModalProps) {
  const [proofUrl, setProofUrl] = useState("");
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [proofType, setProofType] = useState<"url" | "file">("url");
  const { toast } = useToast();

  const handleSubmitProof = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const table = challengeType === "engagement" ? "engagements" : "follows";
      let finalProofUrl = proofUrl;

      if (proofType === "file" && proofFile) {
        const fileName = `${challengeId}-${Date.now()}-${proofFile.name}`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from("challenge-proofs")
          .upload(fileName, proofFile);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from("challenge-proofs")
          .getPublicUrl(fileName);

        finalProofUrl = publicUrl;
      }

      const { error } = await supabase
        .from(table)
        .update({
          challenge_status: "proof_submitted",
          challenge_proof: finalProofUrl,
        })
        .eq("id", challengeId);

      if (error) throw error;

      const { data: challenge } = await supabase
        .from(table)
        .select('*')
        .eq('id', challengeId)
        .maybeSingle();

      if (challenge?.challenger_id) {
        await supabase.from('notifications').insert([{
          user_id: challenge.challenger_id,
          type: 'proof_submitted',
          message: `A user has submitted proof for your challenge`,
        }]);
      }

      toast({
        title: "Proof Submitted",
        description: "Your proof has been submitted successfully.",
      });

      onClose();
    } catch (error) {
      console.error("Error submitting proof:", error);
      toast({
        title: "Error",
        description: "Failed to submit proof. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Submit Challenge Proof
          </DialogTitle>
          <DialogDescription>
            Please provide proof of your {challengeType}
          </DialogDescription>
        </DialogHeader>
        <Tabs defaultValue="url" onValueChange={(value) => setProofType(value as "url" | "file")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="url" className="flex items-center gap-2">
              <LinkIcon className="h-4 w-4" />
              URL
            </TabsTrigger>
            <TabsTrigger value="file" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Screenshot
            </TabsTrigger>
          </TabsList>
          <form onSubmit={handleSubmitProof} className="space-y-4 mt-4">
            <TabsContent value="url">
              <ProofUrlForm proofUrl={proofUrl} setProofUrl={setProofUrl} />
            </TabsContent>
            <TabsContent value="file">
              <ProofFileForm proofFile={proofFile} setProofFile={setProofFile} />
            </TabsContent>
            <div className="flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting || (proofType === "url" ? !proofUrl : !proofFile)}
                className="flex items-center gap-2"
              >
                <Upload className="h-4 w-4" />
                {isSubmitting ? "Submitting..." : "Submit Proof"}
              </Button>
            </div>
          </form>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}