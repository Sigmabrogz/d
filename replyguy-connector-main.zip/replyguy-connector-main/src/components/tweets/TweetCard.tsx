import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";

interface TweetCardProps {
  tweet: {
    id: string;
    url: string;
    created_at: string;
    user_id: string;
    engagement_count: number | null;
    profile: {
      username: string | null;
      avatar_url: string | null;
      twitter_handle: string | null;
    } | null;
  };
  currentUser: string | null;
  isEngaged: boolean;
  onEngage: (tweetId: string) => void;
}

export const TweetCard = ({ tweet, currentUser, isEngaged, onEngage }: TweetCardProps) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const isNewTweet = (date: string) => {
    const tweetDate = new Date(date);
    const now = new Date();
    const diffInHours = (now.getTime() - tweetDate.getTime()) / (1000 * 60 * 60);
    return diffInHours <= 24;
  };

  // Calculate the displayed engagement count
  const displayedEngagementCount = isEngaged 
    ? (tweet.engagement_count || 0) 
    : tweet.engagement_count || 0;

  const renderTweetActions = () => {
    if (currentUser === tweet.user_id) {
      return (
        <div className="text-sm text-muted-foreground">
          {displayedEngagementCount} users have engaged so far
        </div>
      );
    }

    return (
      <Button
        onClick={() => onEngage(tweet.id)}
        variant={isEngaged ? "outline" : "outline"}
        disabled={isEngaged}
        className={`
          rounded-full px-6 flex items-center gap-2 transition-all duration-200
          ${isEngaged 
            ? 'bg-[#e7f9f3] text-[#00ba7c] border-[#a2e6d5] hover:bg-[#d4f3e9]' 
            : 'bg-[#e8f5fe] text-[#1d9bf0] border-[#c4e1ff] hover:bg-[#d1ebff]'}
        `}
      >
        {isEngaged && (
          <span className="bg-white rounded-full w-5 h-5 flex items-center justify-center shadow-sm">
            <Check className="h-3 w-3 text-[#00ba7c]" />
          </span>
        )}
        {isEngaged ? 'Engaged' : 'Engage'}
      </Button>
    );
  };

  return (
    <div className="bg-[#f8f9fa] rounded-xl p-5 mb-4 border border-[#e1e8ed] transition-all duration-200 hover:translate-y-[-2px] hover:shadow-md">
      <div className="flex items-center justify-between mb-3.5">
        <div className="flex flex-col">
          {tweet.profile?.twitter_handle && (
            <span className="font-semibold text-[15px] text-[#0f1419] tracking-tight">
              @{tweet.profile.twitter_handle}
            </span>
          )}
          <span className="text-[13px] text-[#657786] mt-0.5">
            {formatDate(tweet.created_at)}
          </span>
          {isNewTweet(tweet.created_at) && !isEngaged && (
            <Badge variant="secondary" className="bg-blue-500 text-white mt-1 w-fit">
              NEW
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-[#657786]">
            {displayedEngagementCount} engagements
          </span>
          {renderTweetActions()}
        </div>
      </div>
      <a
        href={tweet.url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-[#1d9bf0] text-sm hover:underline break-all block mt-3 py-2 px-0 rounded hover:bg-[#f0f6ff] transition-colors"
      >
        {tweet.url}
      </a>
    </div>
  );
};