import { NavLink, useNavigate, useLocation } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  LayoutDashboard,
  MessageSquare,
  UserPlus,
  Shield,
  User,
  Bell,
  HelpCircle,
  LogOut,
  Menu,
  X,
  Eye,
  EyeOff,
  MessageCircle,
} from "lucide-react";
import { Button } from "./ui/button";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { useIsMobile } from "@/hooks/use-mobile";

export function AppSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = useState(!isMobile);
  const [showNav, setShowNav] = useState(true);
  const queryClient = useQueryClient();
  
  useEffect(() => {
    setIsOpen(!isMobile);
  }, [isMobile]);

  // Reset unread count when on notifications page
  useEffect(() => {
    if (location.pathname === '/notifications') {
      queryClient.setQueryData(['notifications', 'unread'], 0);
    }
  }, [location.pathname, queryClient]);

  const { data: unreadCount } = useQuery({
    queryKey: ['notifications', 'unread'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return 0;

      const { count } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('read', false);

      return count || 0;
    }
  });

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of your account",
      });
      navigate("/");
    } catch (error) {
      toast({
        title: "Error logging out",
        description: "There was a problem logging out. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!showNav) {
    return (
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setShowNav(true)}
        className="fixed top-4 left-4 z-50"
      >
        <Eye className="h-6 w-6" />
      </Button>
    );
  }

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 md:hidden"
      >
        {isOpen ? (
          <X className="h-6 w-6" />
        ) : (
          <Menu className="h-6 w-6" />
        )}
      </Button>

      <aside 
        className={`
          fixed inset-y-0 left-0 z-40 
          transform transition-transform duration-200 ease-in-out
          md:relative md:transform-none
          flex flex-col h-full w-64 bg-sidebar text-sidebar-foreground border-r border-sidebar-border
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        <div className="absolute top-4 right-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowNav(false)}
            className="text-sidebar-foreground hover:text-sidebar-accent"
          >
            <EyeOff className="h-5 w-5" />
          </Button>
        </div>

        <nav className="flex-1 p-4 space-y-2 mt-16 md:mt-0">
          <NavLink
            to="/dashboard"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "hover:bg-sidebar-accent/10"
              }`
            }
            onClick={() => isMobile && setIsOpen(false)}
          >
            <LayoutDashboard className="h-5 w-5" />
            Dashboard
          </NavLink>

          <NavLink
            to="/engagement"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "hover:bg-sidebar-accent/10"
              }`
            }
          >
            <MessageSquare className="h-5 w-5" />
            Engagement Feed
          </NavLink>

          <NavLink
            to="/follow"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "hover:bg-sidebar-accent/10"
              }`
            }
          >
            <UserPlus className="h-5 w-5" />
            Follow
          </NavLink>

          <NavLink
            to="/challenge"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "hover:bg-sidebar-accent/10"
              }`
            }
          >
            <Shield className="h-5 w-5" />
            Challenges
          </NavLink>

          <NavLink
            to="/profile"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "hover:bg-sidebar-accent/10"
              }`
            }
          >
            <User className="h-5 w-5" />
            Profile
          </NavLink>

          <NavLink
            to="/notifications"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "hover:bg-sidebar-accent/10"
              }`
            }
          >
            <div className="relative">
              <Bell className="h-5 w-5" />
              {unreadCount && unreadCount > 0 ? (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {unreadCount}
                </span>
              ) : null}
            </div>
            Notifications
          </NavLink>

          <NavLink
            to="/how-it-works"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "hover:bg-sidebar-accent/10"
              }`
            }
            onClick={() => isMobile && setIsOpen(false)}
          >
            <HelpCircle className="h-5 w-5" />
            How It Works
          </NavLink>

          <NavLink
            to="/chat"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "hover:bg-sidebar-accent/10"
              }`
            }
            onClick={() => isMobile && setIsOpen(false)}
          >
            <MessageCircle className="h-5 w-5" />
            Community Chat
          </NavLink>
        </nav>
        
        <div className="p-4 border-t border-sidebar-border">
          <Button
            variant="ghost"
            className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-100/10"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5 mr-2" />
            Logout
          </Button>
        </div>
      </aside>

      {isOpen && isMobile && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}
