import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, Shield, Upload, FileText, Image } from "lucide-react";

export function ChallengeGuide() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          How Challenges Work
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible>
          <AccordionItem value="what">
            <AccordionTrigger>What are Challenges?</AccordionTrigger>
            <AccordionContent>
              <p className="text-muted-foreground">
                Challenges are a way to verify the authenticity of engagements and follows. 
                If someone suspects an engagement or follow is not genuine, they can challenge it,
                requiring the user to provide proof.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="how">
            <AccordionTrigger>How do Challenges Work?</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="h-5 w-5 mt-0.5 text-yellow-500" />
                  <p className="text-muted-foreground">
                    When someone challenges your engagement or follow, you'll receive a notification
                    asking for proof.
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <Upload className="h-5 w-5 mt-0.5 text-blue-500" />
                  <p className="text-muted-foreground">
                    You must submit proof within 24 hours of receiving the challenge.
                  </p>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="proof">
            <AccordionTrigger>What Counts as Valid Proof?</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4">
                <div className="flex items-start gap-2">
                  <FileText className="h-5 w-5 mt-0.5 text-green-500" />
                  <div className="space-y-2">
                    <p className="font-medium">URL Proof</p>
                    <p className="text-muted-foreground">
                      A direct link to your engagement (like, retweet, comment) or follow action
                      on the platform.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Image className="h-5 w-5 mt-0.5 text-purple-500" />
                  <div className="space-y-2">
                    <p className="font-medium">Screenshot Proof</p>
                    <p className="text-muted-foreground">
                      A clear screenshot showing your engagement or follow action. The screenshot
                      must include visible timestamps and usernames.
                    </p>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="rules">
            <AccordionTrigger>Challenge Rules</AccordionTrigger>
            <AccordionContent>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>You can only challenge an engagement or follow once</li>
                <li>Proof must be submitted within 24 hours</li>
                <li>Screenshots must be under 5MB and in image format</li>
                <li>URLs must be direct links to the engagement/follow</li>
                <li>False challenges may result in account restrictions</li>
              </ul>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}