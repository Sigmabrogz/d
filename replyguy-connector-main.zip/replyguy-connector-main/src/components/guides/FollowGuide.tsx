import { Card, CardContent } from "@/components/ui/card";

export function FollowGuide() {
  return (
    <Card>
      <CardContent className="space-y-4 pt-6">
        <div className="space-y-2">
          <h3 className="text-lg font-semibold">How Following Works</h3>
          <p className="text-sm text-muted-foreground">
            Build your network by following other users and verifying genuine followers.
          </p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium">1. Find Users</h4>
            <p className="text-sm text-muted-foreground">
              Browse through the list of users in the community.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">2. Mark as Followed</h4>
            <p className="text-sm text-muted-foreground">
              Click "Mark as Followed" when you've followed someone on Twitter.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">3. Challenge System</h4>
            <p className="text-sm text-muted-foreground">
              Users can challenge your follow claim if they don't see you in their followers list.
              Be ready to provide a screenshot or proof of your follow.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">4. Maintain Connections</h4>
            <p className="text-sm text-muted-foreground">
              Keep your follows active and engage with your network regularly.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}