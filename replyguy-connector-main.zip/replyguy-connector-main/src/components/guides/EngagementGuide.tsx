import { Card, CardContent } from "@/components/ui/card";

export function EngagementGuide() {
  return (
    <Card>
      <CardContent className="space-y-4 pt-6">
        <div className="space-y-2">
          <h3 className="text-lg font-semibold">How Engagement Works</h3>
          <p className="text-sm text-muted-foreground">
            The Engagement Feed is where you can interact with other users' tweets and build genuine connections.
          </p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium">1. Browse Tweets</h4>
            <p className="text-sm text-muted-foreground">
              Scroll through tweets shared by other users in the community.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">2. Engage with Tweets</h4>
            <p className="text-sm text-muted-foreground">
              Click the "Engage" button to indicate that you've meaningfully interacted with the tweet 
              (like, retweet, or comment).
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">3. Verification System</h4>
            <p className="text-sm text-muted-foreground">
              Tweet owners can verify your engagement and may challenge if they don't see your interaction.
              Be prepared to provide proof of your engagement if challenged.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">4. Build Trust</h4>
            <p className="text-sm text-muted-foreground">
              Genuine interactions help build trust within the community and increase your credibility.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}