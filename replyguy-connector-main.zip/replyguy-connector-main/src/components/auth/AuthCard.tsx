import { useState } from "react";
import { LoginForm } from "./LoginForm";
import { SignupForm } from "./SignupForm";
import { motion } from "framer-motion";
import { MessageSquare, Heart, BarChart2, Users } from "lucide-react";
import { AnimatedTweetDemo } from "./AnimatedTweetDemo";

export const AuthCard = () => {
  const [isLogin, setIsLogin] = useState(true);

  const engagementMetrics = [
    {
      icon: <Heart className="text-red-500" />,
      label: "Meaningful Engagement",
      description: "Get genuine interactions from active Twitter users",
      delay: 0.2
    },
    {
      icon: <MessageSquare className="text-blue-500" />,
      label: "Quality Comments",
      description: "Receive thoughtful responses that add value",
      delay: 0.4
    },
    {
      icon: <BarChart2 className="text-green-500" />,
      label: "Growing Impressions",
      description: "Watch your Twitter presence expand organically",
      delay: 0.6
    },
    {
      icon: <Users className="text-purple-500" />,
      label: "Community Support",
      description: "Join a network of engaged Twitter users",
      delay: 0.8
    }
  ];

  return (
    <div className="w-full max-w-6xl mx-auto space-y-12 px-4">
      {/* Hero Section with Form */}
      <div className="grid md:grid-cols-2 gap-8 items-start">
        {/* Left Column: Title, Description, and GIF */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-left space-y-6"
        >
          <div className="space-y-4">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              Engage & Grow Together
            </motion.h1>
            <motion.p 
              className="text-lg md:text-xl text-gray-600 font-medium"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              A selective community of 50 active Twitter users helping each other grow through consistent engagement
            </motion.p>
          </div>
          
          {/* Added GIF */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="w-full rounded-lg overflow-hidden shadow-lg"
          >
            <img
              src="https://i.pinimg.com/originals/a8/39/4f/a8394f8fae4880323413a3df4ade9ace.gif"
              alt="Social Media Animation"
              className="w-full h-auto object-cover rounded-lg"
            />
          </motion.div>
        </motion.div>

        {/* Right Column: Auth Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="bg-white rounded-xl shadow-lg p-8 space-y-6 border border-gray-100"
        >
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            {isLogin ? "Welcome Back!" : "Join the Community"}
          </h2>
          {isLogin ? <LoginForm /> : <SignupForm />}
          
          <div className="pt-6 text-center border-t border-gray-100">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-sm text-blue-600 hover:text-blue-800 hover:underline transition-colors"
            >
              {isLogin ? "Need an account? Sign up" : "Already have an account? Log in"}
            </button>
          </div>
        </motion.div>
      </div>

      {/* Benefits Grid */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8"
      >
        <h2 className="text-2xl font-bold text-gray-800 mb-8 text-center">Why Join Our Community?</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {engagementMetrics.map((metric, index) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: metric.delay, duration: 0.5 }}
              className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 flex items-start space-x-4"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: metric.delay + 0.2 }}
                className="p-3 bg-gray-50 rounded-lg"
              >
                {metric.icon}
              </motion.div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800 mb-1">{metric.label}</h3>
                <p className="text-sm text-gray-600">{metric.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Tweet Demo Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9 }}
        className="relative"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-purple-50/50 rounded-2xl" />
        <div className="relative">
          <h2 className="text-2xl font-bold text-gray-800 mb-8 text-center">See Engagement in Action</h2>
          <AnimatedTweetDemo />
        </div>
      </motion.div>
    </div>
  );
};