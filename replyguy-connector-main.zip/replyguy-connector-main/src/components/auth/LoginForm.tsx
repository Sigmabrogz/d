import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [resetPasswordMode, setResetPasswordMode] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const checkProfileCompletion = async (userId: string) => {
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('full_name, username, twitter_handle')
      .eq('id', userId)
      .single();

    if (error) {
      console.error('Error checking profile:', error);
      return false;
    }

    return !!(profile?.full_name && profile?.username && profile?.twitter_handle);
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: 'https://hodlr.fun/reset-password',
      });

      if (error) throw error;

      toast({
        title: "Password reset email sent",
        description: "Please check your email for the password reset link.",
      });
      
      setResetPasswordMode(false);
    } catch (error: any) {
      toast({
        title: "Password reset failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { data: { user }, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      // Check if profile is complete
      if (user) {
        const isProfileComplete = await checkProfileCompletion(user.id);
        
        toast({
          title: "Welcome back!",
          description: isProfileComplete 
            ? "Successfully logged into ReplyGuy" 
            : "Please complete your profile details to continue",
        });
        
        // Redirect based on profile completion
        if (isProfileComplete) {
          navigate("/dashboard");
        } else {
          navigate("/profile");
        }
      }
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (resetPasswordMode) {
    return (
      <form onSubmit={handleResetPassword} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="reset-email">Email address</Label>
          <Input
            id="reset-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            required
            autoComplete="email"
          />
        </div>

        <Button
          type="submit"
          className="w-full"
          disabled={loading}
        >
          {loading ? "Sending reset link..." : "Send reset link"}
        </Button>

        <div className="text-center">
          <button
            type="button"
            onClick={() => setResetPasswordMode(false)}
            className="text-sm text-gray-600 hover:text-gray-900 hover:underline"
          >
            Back to login
          </button>
        </div>
      </form>
    );
  }

  return (
    <form onSubmit={handleLogin} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="email">Email address</Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          required
          autoComplete="email"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter your password"
          required
          autoComplete="current-password"
        />
      </div>

      <Button
        type="submit"
        className="w-full"
        disabled={loading}
      >
        {loading ? "Signing in..." : "Sign in"}
      </Button>

      <div className="text-center">
        <button
          type="button"
          onClick={() => setResetPasswordMode(true)}
          className="text-sm text-gray-600 hover:text-gray-900 hover:underline"
        >
          Forgot password?
        </button>
      </div>
    </form>
  );
};