import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, Heart, Repeat, Bookmark, Share2 } from "lucide-react";
import { useState, useEffect } from "react";

export const AnimatedTweetDemo = () => {
  const [likes, setLikes] = useState(0);
  const [comments, setComments] = useState<string[]>([]);
  const [impressions, setImpressions] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [showReplies, setShowReplies] = useState(true);
  const [showTweet, setShowTweet] = useState(true);

  const demoComments = [
    {
      username: "TradingPro",
      handle: "@TradingPro",
      comment: "While I see your point about contrarian trading, it's crucial to note that sentiment alone isn't enough. Technical analysis should still guide entry/exit points. 🎯",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2",
      time: "36s"
    },
    {
      username: "CryptoSage",
      handle: "@CryptoSage",
      comment: "Brilliant observation! I've been tracking this pattern too. The market often overreacts in both directions, creating perfect entry points for patient traders. 📊",
      avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36",
      time: "9m"
    },
    {
      username: "BlockchainPhilosopher",
      handle: "@BlockchainPhilosopher",
      comment: "Respectfully disagree. Sometimes the crowd sentiment reflects genuine market risks. We need to differentiate between irrational fear and legitimate concerns. 🤔",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde",
      time: "12m"
    },
    {
      username: "MarketMaven",
      handle: "@MarketMaven",
      comment: "This strategy worked well in 2023's bear market. Those who bought during peak FUD made incredible returns. Historical data supports your thesis! 📈",
      avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956",
      time: "15m"
    }
  ];

  useEffect(() => {
    // Initial delay to show the tweet
    const showTimer = setTimeout(() => setIsVisible(true), 500);
    
    // Timer to hide the entire tweet after some time
    const hideTimer = setTimeout(() => {
      setShowTweet(false);
    }, 15000); // Hide tweet after 15 seconds

    return () => {
      clearTimeout(showTimer);
      clearTimeout(hideTimer);
    };
  }, []);

  useEffect(() => {
    if (isVisible) {
      const likeInterval = setInterval(() => {
        setLikes(prev => (prev < 2300 ? prev + 100 : prev));
      }, 100);

      const commentInterval = setInterval(() => {
        setComments(prev => {
          if (prev.length < demoComments.length) {
            return [...prev, demoComments[prev.length].comment];
          }
          return prev;
        });
      }, 2000);

      const impressionInterval = setInterval(() => {
        setImpressions(prev => (prev < 107700 ? prev + 1000 : prev));
      }, 50);

      // Add timer to hide replies after some time
      const hideRepliesTimer = setTimeout(() => {
        setShowReplies(false);
      }, 12000); // Hide replies after 12 seconds

      return () => {
        clearInterval(likeInterval);
        clearInterval(commentInterval);
        clearInterval(impressionInterval);
        clearTimeout(hideRepliesTimer);
      };
    }
  }, [isVisible]);

  return (
    <AnimatePresence>
      {isVisible && showTweet && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ 
            opacity: 0, 
            y: -20,
            transition: {
              duration: 0.5,
              ease: "easeInOut"
            }
          }}
          className="bg-black text-white rounded-2xl w-full max-w-[598px] mx-auto mb-8 overflow-hidden"
        >
          <div className="space-y-4 p-4">
            {/* Main Tweet */}
            <div className="flex space-x-3">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0"
              >
                <img 
                  src="https://images.unsplash.com/photo-1579547944212-c4f4961a8dd8"
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              </motion.div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-1">
                  <span className="font-bold text-[15px]">CryptoTrader</span>
                  <svg className="w-4 h-4 text-[#1d9bf0]" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.435.238-.905.238-1.4 0-2.21-1.71-3.998-3.818-3.998-.47 0-.92.084-1.336.25C14.818 2.415 13.51 1.5 12 1.5s-2.816.917-3.437 2.25c-.415-.165-.866-.25-1.336-.25-2.11 0-3.818 1.79-3.818 4 0 .494.083.964.237 1.4-1.272.65-2.147 2.018-2.147 3.6 0 1.495.782 2.798 1.942 3.486-.02.17-.032.34-.032.514 0 2.21 1.708 4 3.818 4 .47 0 .92-.086 1.335-.25.62 1.334 1.926 2.25 3.437 2.25 1.512 0 2.818-.916 3.437-2.25.415.163.865.248 1.336.248 2.11 0 3.818-1.79 3.818-4 0-.174-.012-.344-.033-.513 1.158-.687 1.943-1.99 1.943-3.484zm-6.616-3.334l-4.334 6.5c-.145.217-.382.334-.625.334-.143 0-.288-.04-.416-.126l-.115-.094-2.415-2.415c-.293-.293-.293-.768 0-1.06s.768-.294 1.06 0l1.77 1.767 3.825-5.74c.23-.345.696-.436 1.04-.207.346.23.44.696.21 1.04z"/>
                  </svg>
                  <span className="text-gray-500 text-[15px]">@contrarian_ct</span>
                </div>
                <p className="text-[15px] mt-1 text-left">
                  I have found that the second best way to trade crypto is to go against crypto twitter consensus when people overreact with either euphoria or doom.
                </p>
                <div className="text-gray-500 text-[13px] mt-1">
                  4:07 AM · Jan 28, 2025 · {impressions.toLocaleString()} Views
                </div>
                
                <div className="flex justify-between mt-3 text-gray-500 text-[13px] max-w-[425px]">
                  <motion.div 
                    className="flex items-center space-x-1 group cursor-pointer"
                    animate={{ scale: comments.length > 0 ? [1, 1.2, 1] : 1 }}
                  >
                    <MessageSquare className="w-4 h-4 group-hover:text-[#1d9bf0]" />
                    <span className="group-hover:text-[#1d9bf0]">42</span>
                  </motion.div>
                  <motion.div 
                    className="flex items-center space-x-1 group cursor-pointer"
                    animate={{ scale: [1, 1.2, 1] }}
                  >
                    <Repeat className="w-4 h-4 group-hover:text-[#00ba7c]" />
                    <span className="group-hover:text-[#00ba7c]">4</span>
                  </motion.div>
                  <motion.div 
                    className="flex items-center space-x-1 group cursor-pointer"
                    animate={{ scale: likes > 0 ? [1, 1.2, 1] : 1 }}
                  >
                    <Heart className={`w-4 h-4 group-hover:text-[#f91880] ${likes > 0 ? 'text-[#f91880]' : ''}`} />
                    <span className="group-hover:text-[#f91880]">2.5K</span>
                  </motion.div>
                  <motion.div className="flex items-center space-x-1 group cursor-pointer">
                    <Bookmark className="w-4 h-4 group-hover:text-[#1d9bf0]" />
                    <span className="group-hover:text-[#1d9bf0]">163</span>
                  </motion.div>
                  <Share2 className="w-4 h-4 cursor-pointer hover:text-[#1d9bf0]" />
                </div>
              </div>
            </div>

            {/* Comments with vanishing animation */}
            <AnimatePresence mode="sync">
              {showReplies && (
                <motion.div 
                  className="space-y-4 mt-4 border-t border-gray-800 pt-4"
                  exit={{ 
                    opacity: 0,
                    height: 0,
                    transition: { duration: 0.5 }
                  }}
                >
                  {comments.map((_, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ 
                        opacity: 0,
                        x: -100,
                        transition: { 
                          duration: 0.3,
                          delay: index * 0.1 // Stagger the exit animations
                        }
                      }}
                      className="flex space-x-3"
                    >
                      <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
                        <img 
                          src={demoComments[index].avatar}
                          alt={demoComments[index].username}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center flex-wrap space-x-1">
                          <span className="font-bold text-[15px]">{demoComments[index].username}</span>
                          <svg className="w-4 h-4 text-[#1d9bf0]" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.435.238-.905.238-1.4 0-2.21-1.71-3.998-3.818-3.998-.47 0-.92.084-1.336.25C14.818 2.415 13.51 1.5 12 1.5s-2.816.917-3.437 2.25c-.415-.165-.866-.25-1.336-.25-2.11 0-3.818 1.79-3.818 4 0 .494.083.964.237 1.4-1.272.65-2.147 2.018-2.147 3.6 0 1.495.782 2.798 1.942 3.486-.02.17-.032.34-.032.514 0 2.21 1.708 4 3.818 4 .47 0 .92-.086 1.335-.25.62 1.334 1.926 2.25 3.437 2.25 1.512 0 2.818-.916 3.437-2.25.415.163.865.248 1.336.248 2.11 0 3.818-1.79 3.818-4 0-.174-.012-.344-.033-.513 1.158-.687 1.943-1.99 1.943-3.484zm-6.616-3.334l-4.334 6.5c-.145.217-.382.334-.625.334-.143 0-.288-.04-.416-.126l-.115-.094-2.415-2.415c-.293-.293-.293-.768 0-1.06s.768-.294 1.06 0l1.77 1.767 3.825-5.74c.23-.345.696-.436 1.04-.207.346.23.44.696.21 1.04z"/>
                          </svg>
                          <span className="text-gray-500 text-[15px]">{demoComments[index].handle}</span>
                          <span className="text-gray-500">·</span>
                          <span className="text-gray-500 text-[15px]">{demoComments[index].time}</span>
                        </div>
                        <p className="text-[15px] mt-1 text-left">{demoComments[index].comment}</p>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};