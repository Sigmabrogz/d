import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AppSidebar } from "@/components/AppSidebar";
import Index from "@/pages/Index";
import Dashboard from "@/pages/Dashboard";
import EngagementFeed from "@/pages/EngagementFeed";
import Follow from "@/pages/Follow";
import Challenge from "@/pages/Challenge";
import Profile from "@/pages/Profile";
import Notifications from "@/pages/Notifications";
import HowItWorks from "@/pages/HowItWorks";
import Chat from "@/pages/Chat";

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route
            path="/*"
            element={
              <div className="flex h-screen">
                <AppSidebar />
                <main className="flex-1 overflow-y-auto bg-background">
                  <Routes>
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/engagement" element={<EngagementFeed />} />
                    <Route path="/follow" element={<Follow />} />
                    <Route path="/challenge" element={<Challenge />} />
                    <Route path="/profile" element={<Profile />} />
                    <Route path="/notifications" element={<Notifications />} />
                    <Route path="/how-it-works" element={<HowItWorks />} />
                    <Route path="/chat" element={<Chat />} />
                    <Route path="*" element={<Navigate to="/dashboard" replace />} />
                  </Routes>
                </main>
              </div>
            }
          />
        </Routes>
        <Toaster />
      </Router>
    </QueryClientProvider>
  );
}

export default App;