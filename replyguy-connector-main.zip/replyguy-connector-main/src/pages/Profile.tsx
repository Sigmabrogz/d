import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

const Profile = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [isProfileComplete, setIsProfileComplete] = useState(false);
  const [validationErrors, setValidationErrors] = useState({
    full_name: "",
    username: "",
    twitter_handle: ""
  });
  const [profile, setProfile] = useState({
    full_name: "",
    username: "",
    avatar_url: "",
    twitter_handle: ""
  });

  useEffect(() => {
    const getProfile = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          navigate("/");
          return;
        }
        setUser(user);

        const { data: profileData, error } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", user.id)
          .single();

        if (error) throw error;

        if (profileData) {
          setProfile({
            full_name: profileData.full_name || "",
            username: profileData.username || "",
            avatar_url: profileData.avatar_url || "",
            twitter_handle: profileData.twitter_handle || ""
          });
          
          const isComplete = profileData.full_name && 
                           profileData.username && 
                           profileData.twitter_handle;
          setIsProfileComplete(!!isComplete);
          
          if (isComplete) {
            toast({
              title: "Profile already complete",
              description: "Redirecting to dashboard...",
            });
            setTimeout(() => navigate("/dashboard"), 2000);
          }
        }
      } catch (error: any) {
        toast({
          title: "Error fetching profile",
          description: error.message,
          variant: "destructive",
        });
      }
    };

    getProfile();
  }, [navigate, toast]);

  const validateInputs = () => {
    const errors = {
      full_name: "",
      username: "",
      twitter_handle: ""
    };
    
    if (!profile.full_name.trim()) {
      errors.full_name = "Full name is required";
    } else if (profile.full_name.length < 2) {
      errors.full_name = "Full name must be at least 2 characters";
    }

    if (!profile.username.trim()) {
      errors.username = "Username is required";
    } else if (profile.username.length < 3) {
      errors.username = "Username must be at least 3 characters";
    } else if (!/^[a-zA-Z0-9_]+$/.test(profile.username)) {
      errors.username = "Username can only contain letters, numbers, and underscores";
    }

    if (!profile.twitter_handle.trim()) {
      errors.twitter_handle = "Twitter handle is required";
    } else if (!profile.twitter_handle.startsWith("@")) {
      errors.twitter_handle = "Twitter handle must start with @";
    }

    setValidationErrors(errors);
    return !Object.values(errors).some(error => error !== "");
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isProfileComplete) return;
    
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
    
    // Clear validation error when user starts typing
    setValidationErrors(prev => ({
      ...prev,
      [name]: ""
    }));
  };

  const handleSave = async () => {
    if (isProfileComplete) return;
    
    if (!validateInputs()) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors before saving",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          full_name: profile.full_name.trim(),
          username: profile.username.trim(),
          twitter_handle: profile.twitter_handle.trim(),
        })
        .eq("id", user?.id);

      if (error) throw error;

      toast({
        title: "Profile updated",
        description: "Your profile has been set up successfully. Redirecting to dashboard...",
      });
      
      setIsProfileComplete(true);
      setTimeout(() => navigate("/dashboard"), 2000);
    } catch (error: any) {
      toast({
        title: "Error updating profile",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <h1 className="text-2xl font-bold text-center">Complete Your Profile</h1>
            <p className="text-muted-foreground text-center">
              {isProfileComplete 
                ? "Your profile is complete. Redirecting to dashboard..." 
                : "Please fill in your profile information carefully"}
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {!isProfileComplete && (
              <Alert variant="destructive" className="bg-yellow-50 border-yellow-200">
                <AlertCircle className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-800">
                  Please fill in your details carefully. This information will be used to identify you in the community.
                </AlertDescription>
              </Alert>
            )}

            <div className="flex flex-col items-center space-y-4">
              <Avatar className="w-24 h-24">
                <AvatarImage src={profile.avatar_url || undefined} />
                <AvatarFallback>
                  {profile.full_name?.charAt(0) || "U"}
                </AvatarFallback>
              </Avatar>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="full_name">
                  Full Name *
                </Label>
                <Input
                  id="full_name"
                  name="full_name"
                  value={profile.full_name}
                  onChange={handleChange}
                  placeholder="Enter your full name"
                  disabled={isProfileComplete || loading}
                  required
                  className={validationErrors.full_name ? "border-red-500" : ""}
                />
                {validationErrors.full_name && (
                  <p className="text-sm text-red-500 mt-1">{validationErrors.full_name}</p>
                )}
              </div>

              <div>
                <Label htmlFor="username">
                  Username *
                </Label>
                <Input
                  id="username"
                  name="username"
                  value={profile.username}
                  onChange={handleChange}
                  placeholder="Choose a username (letters, numbers, underscores only)"
                  disabled={isProfileComplete || loading}
                  required
                  className={validationErrors.username ? "border-red-500" : ""}
                />
                {validationErrors.username && (
                  <p className="text-sm text-red-500 mt-1">{validationErrors.username}</p>
                )}
              </div>

              <div>
                <Label htmlFor="twitter_handle">
                  Twitter Handle *
                </Label>
                <Input
                  id="twitter_handle"
                  name="twitter_handle"
                  value={profile.twitter_handle}
                  onChange={handleChange}
                  placeholder="@username"
                  disabled={isProfileComplete || loading}
                  required
                  className={validationErrors.twitter_handle ? "border-red-500" : ""}
                />
                {validationErrors.twitter_handle && (
                  <p className="text-sm text-red-500 mt-1">{validationErrors.twitter_handle}</p>
                )}
              </div>

              {!isProfileComplete && (
                <Button 
                  className="w-full mt-4"
                  onClick={handleSave}
                  disabled={loading}
                >
                  {loading ? "Saving..." : "Save Profile Details"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Profile;