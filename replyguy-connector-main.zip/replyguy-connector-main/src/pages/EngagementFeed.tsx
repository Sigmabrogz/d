import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EngagementGuide } from "@/components/guides/EngagementGuide";
import { UnengagedTweetsCard } from "@/components/dashboard/UnengagedTweetsCard";
import { TweetCard } from "@/components/tweets/TweetCard";
import { useTweets } from "@/hooks/useTweets";

const EngagementFeed = () => {
  const { toast } = useToast();
  const { tweets, loading, userEngagements, currentUser, fetchTweets, fetchUserEngagements } = useTweets();

  const isEngaged = (tweetId: string) => {
    return userEngagements.some(engagement => engagement.tweet_id === tweetId);
  };

  const handleEngage = async (tweetId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Authentication required",
          description: "Please log in to engage with tweets",
          variant: "destructive",
        });
        return;
      }

      const { data: existingEngagement } = await supabase
        .from('engagements')
        .select('*')
        .eq('tweet_id', tweetId)
        .eq('user_id', user.id)
        .maybeSingle();

      if (existingEngagement) {
        toast({
          title: "Already engaged",
          description: "You have already engaged with this tweet",
          variant: "destructive",
        });
        return;
      }

      const { data: tweetData, error: tweetError } = await supabase
        .from('tweets')
        .select(`
          user_id,
          engagement_count,
          profiles!tweets_user_id_fkey_profiles (
            username,
            twitter_handle
          )
        `)
        .eq('id', tweetId)
        .single();

      if (tweetError || !tweetData) {
        throw new Error('Tweet not found');
      }

      const { data: engagingUserProfile } = await supabase
        .from('profiles')
        .select('username, twitter_handle')
        .eq('id', user.id)
        .single();

      const { error: insertError } = await supabase
        .from('engagements')
        .insert([
          { tweet_id: tweetId, user_id: user.id, status: 'engaged' }
        ]);

      if (insertError) throw insertError;

      const { error: updateError } = await supabase
        .from('tweets')
        .update({ 
          engagement_count: (tweetData.engagement_count || 0) + 1 
        })
        .eq('id', tweetId);

      if (updateError) throw updateError;

      if (tweetData.user_id !== user.id) {
        const engagingUsername = engagingUserProfile?.twitter_handle || engagingUserProfile?.username || 'Someone';
        const { error: notificationError } = await supabase
          .from('notifications')
          .insert([{
            user_id: tweetData.user_id,
            type: 'engagement',
            message: `@${engagingUsername} engaged with your tweet`,
          }]);

        if (notificationError) {
          console.error('Error creating notification:', notificationError);
          throw notificationError;
        }
      }

      toast({
        title: "Success",
        description: "Engagement recorded successfully",
      });

      fetchUserEngagements();
      fetchTweets();
    } catch (error) {
      console.error('Error recording engagement:', error);
      toast({
        title: "Error",
        description: "Failed to record engagement",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto p-4 space-y-6">
      <h1 className="text-3xl font-bold">Engagement Feed</h1>
      
      <div className="grid gap-4 md:grid-cols-1">
        <UnengagedTweetsCard />
      </div>

      <Tabs defaultValue="feed" className="space-y-6">
        <TabsList>
          <TabsTrigger value="feed">Available Tweets</TabsTrigger>
          <TabsTrigger value="guide">How It Works</TabsTrigger>
        </TabsList>

        <TabsContent value="feed">
          <Card>
            <CardHeader>
              <CardTitle>Available Tweets</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <p className="text-center text-muted-foreground py-8">
                  Loading tweets...
                </p>
              ) : tweets.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  No tweets available for engagement
                </p>
              ) : (
                <div className="space-y-4">
                  {tweets.map((tweet) => (
                    <TweetCard
                      key={tweet.id}
                      tweet={tweet}
                      currentUser={currentUser}
                      isEngaged={isEngaged(tweet.id)}
                      onEngage={handleEngage}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guide">
          <EngagementGuide />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EngagementFeed;