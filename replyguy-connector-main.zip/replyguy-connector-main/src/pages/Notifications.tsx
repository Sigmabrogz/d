import { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Bell, ThumbsUp, Shield, Upload, AlertTriangle } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

interface Notification {
  id: string;
  type: string;
  message: string;
  created_at: string;
  read: boolean;
  user_id: string;
}

const Notifications = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: notifications, isLoading } = useQuery({
    queryKey: ['notifications'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        toast({
          title: "Error",
          description: "Failed to load notifications",
          variant: "destructive",
        });
        throw error;
      }

      return data as Notification[];
    },
  });

  // Mark all notifications as read when the component mounts
  useEffect(() => {
    const markNotificationsAsRead = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('user_id', user.id)
        .eq('read', false);

      if (error) {
        console.error('Error marking notifications as read:', error);
        return;
      }

      // Invalidate both notifications and unread count queries
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
      queryClient.invalidateQueries({ queryKey: ['notifications', 'unread'] });
    };

    markNotificationsAsRead();
  }, [queryClient]);

  const handleChallenge = async (notificationId: string, type: string) => {
    try {
      const { data: notification } = await supabase
        .from('notifications')
        .select('*')
        .eq('id', notificationId)
        .single();

      if (!notification) {
        throw new Error('Notification not found');
      }

      // Mark the current notification as read
      await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', notificationId);

      // Extract username from the original notification message
      const usernameMatch = notification.message.match(/@(\w+)/);
      const username = usernameMatch ? usernameMatch[1] : 'Someone';

      // Get the challenger's profile
      const { data: { user } } = await supabase.auth.getUser();
      const { data: challengerProfile } = await supabase
        .from('profiles')
        .select('username, twitter_handle')
        .eq('id', user?.id)
        .single();

      const challengerUsername = challengerProfile?.twitter_handle || challengerProfile?.username || 'Someone';

      // Update the engagement or follow status based on type
      if (type === 'engagement') {
        await supabase
          .from('engagements')
          .update({ challenge_status: 'challenged' })
          .eq('user_id', notification.user_id);
      } else if (type === 'follow') {
        await supabase
          .from('follows')
          .update({ challenge_status: 'challenged' })
          .eq('follower_id', notification.user_id);
      }

      // Create a challenge notification
      const { error: notificationError } = await supabase
        .from('notifications')
        .insert([{
          user_id: notification.user_id,
          type: 'challenge_response',
          message: `@${challengerUsername} has challenged your ${type}. Please provide proof.`,
        }]);

      if (notificationError) throw notificationError;

      queryClient.invalidateQueries({ queryKey: ['notifications'] });
      
      toast({
        title: "Challenge Sent",
        description: `The ${type} has been challenged`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to challenge",
        variant: "destructive",
      });
    }
  };

  const handleSubmitProof = async (notificationId: string, type: string) => {
    try {
      // For now, we'll just mark it as proof submitted
      // In a future update, we'll add actual proof submission UI
      const proofUrl = "Proof submitted"; // This will be replaced with actual proof URL

      if (type === 'engagement') {
        await supabase
          .from('engagements')
          .update({ 
            challenge_status: 'proof_submitted',
            challenge_proof: proofUrl
          })
          .eq('user_id', notificationId);
      } else if (type === 'follow') {
        await supabase
          .from('follows')
          .update({ 
            challenge_status: 'proof_submitted',
            challenge_proof: proofUrl
          })
          .eq('follower_id', notificationId);
      }

      toast({
        title: "Proof Submitted",
        description: "Your proof has been submitted for review",
      });

      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit proof",
        variant: "destructive",
      });
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'engagement':
        return <ThumbsUp className="w-4 h-4 text-blue-500" />;
      case 'challenge':
      case 'challenge_response':
        return <Shield className="w-4 h-4 text-yellow-500" />;
      default:
        return <Bell className="w-4 h-4" />;
    }
  };

  const getNotificationAction = (notification: Notification) => {
    if (notification.read) return null;

    switch (notification.type) {
      case 'engagement':
        return (
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleChallenge(notification.id, 'engagement')}
            className="flex items-center gap-1"
          >
            <Shield className="w-4 h-4" />
            Challenge
          </Button>
        );
      case 'follow':
        return (
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleChallenge(notification.id, 'follow')}
            className="flex items-center gap-1"
          >
            <Shield className="w-4 h-4" />
            Challenge
          </Button>
        );
      case 'challenge_response':
        return (
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleSubmitProof(notification.id, 'engagement')}
            className="flex items-center gap-1"
          >
            <Upload className="w-4 h-4" />
            Submit Proof
          </Button>
        );
      default:
        return null;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="container mx-auto p-4 space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-2">
        <Bell className="w-6 h-6" />
        Notifications
      </h1>

      <Alert className="bg-yellow-50 border-yellow-200">
        <AlertTriangle className="h-4 w-4 text-yellow-600" />
        <AlertDescription className="text-yellow-800">
          Please use the challenge feature responsibly. Unnecessary challenges may result in account restrictions. 
          Only challenge if you believe there's a genuine violation of engagement rules.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-center text-muted-foreground py-8">
              Loading notifications...
            </p>
          ) : !notifications || notifications.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No notifications yet
            </p>
          ) : (
            <div className="space-y-4">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`flex items-start justify-between gap-4 p-4 rounded-lg border ${
                    notification.read ? 'bg-gray-50' : 'bg-white'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-grow">
                      <p className={`${notification.read ? 'text-gray-600' : 'text-gray-900'}`}>
                        {notification.message}
                      </p>
                      <p className="text-sm text-gray-500">
                        {formatDate(notification.created_at)}
                      </p>
                    </div>
                  </div>
                  {getNotificationAction(notification)}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Notifications;
