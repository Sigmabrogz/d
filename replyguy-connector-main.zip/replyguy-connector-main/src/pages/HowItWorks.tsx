import React from "react";
import { ChallengeGuide } from "@/components/ChallengeGuide";
import { EngagementGuide } from "@/components/guides/EngagementGuide";
import { FollowGuide } from "@/components/guides/FollowGuide";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  MessageSquare, 
  UserPlus, 
  Shield,
  Twitter,
  AlertTriangle,
  Inbox
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export default function HowItWorks() {
  const { data: nonEngagedCount } = useQuery({
    queryKey: ['nonEngagedTweets'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return 0;

      const { count } = await supabase
        .from('tweets')
        .select('*', { count: 'exact', head: true })
        .eq('engagement_count', 0);

      return count || 0;
    }
  });

  return (
    <div className="container mx-auto p-8 space-y-8">
      <div className="text-center space-y-4 mb-8">
        <h1 className="text-4xl font-bold">How ReplyGuy Works</h1>
        <p className="text-xl text-muted-foreground">
          Your platform for authentic Twitter engagement and community building
        </p>
      </div>

      {nonEngagedCount !== undefined && nonEngagedCount > 0 && (
        <Card className="bg-blue-50 mb-8">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Inbox className="h-5 w-5 text-blue-500" />
              <p className="text-blue-700">
                There are currently <span className="font-bold">{nonEngagedCount}</span> tweets waiting for engagement. 
                Help the community grow by engaging with these tweets!
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Twitter className="h-6 w-6 text-blue-400" />
            Platform Overview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-4">
                  <MessageSquare className="h-5 w-5 text-blue-500" />
                  <h3 className="font-semibold">Tweet Engagement</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Share your tweets and engage with others through likes, retweets, and meaningful comments.
                  Track your engagement and build genuine connections.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-4">
                  <UserPlus className="h-5 w-5 text-green-500" />
                  <h3 className="font-semibold">Follow System</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Connect with other users by following them on Twitter. 
                  Build your network with authentic followers who share your interests.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-4">
                  <Shield className="h-5 w-5 text-purple-500" />
                  <h3 className="font-semibold">Challenge System</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Maintain authenticity through our challenge system. 
                  Verify engagements and follows to ensure genuine interactions.
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-blue-50">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 mb-4">
                <AlertTriangle className="h-5 w-5 text-yellow-500" />
                <h3 className="font-semibold">Important Rules</h3>
              </div>
              <ul className="list-disc list-inside space-y-2 text-sm text-muted-foreground">
                <li>Maximum 4 tweet submissions per day</li>
                <li>All engagements must be genuine and meaningful</li>
                <li>Challenges must be responded to within 24 hours</li>
                <li>Follow-for-follow is not guaranteed or enforced</li>
                <li>Spam or automated engagement is strictly prohibited</li>
                <li>Users must have a valid Twitter handle in their profile</li>
              </ul>
            </CardContent>
          </Card>
        </CardContent>
      </Card>

      <Tabs defaultValue="engagement" className="space-y-6">
        <TabsList className="grid grid-cols-3 w-full md:w-[400px] mx-auto">
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="follow">Following</TabsTrigger>
          <TabsTrigger value="challenge">Challenges</TabsTrigger>
        </TabsList>

        <TabsContent value="engagement">
          <EngagementGuide />
        </TabsContent>

        <TabsContent value="follow">
          <FollowGuide />
        </TabsContent>

        <TabsContent value="challenge">
          <ChallengeGuide />
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Getting Started
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <ol className="list-decimal list-inside space-y-4">
            <li className="text-muted-foreground">
              <span className="font-medium text-foreground">Create your account</span>
              <p className="ml-6 mt-1">Sign up and add your Twitter handle to your profile.</p>
            </li>
            <li className="text-muted-foreground">
              <span className="font-medium text-foreground">Submit your tweets</span>
              <p className="ml-6 mt-1">Share tweets you'd like the community to engage with.</p>
            </li>
            <li className="text-muted-foreground">
              <span className="font-medium text-foreground">Engage with others</span>
              <p className="ml-6 mt-1">Like, retweet, and comment on tweets from other users.</p>
            </li>
            <li className="text-muted-foreground">
              <span className="font-medium text-foreground">Connect with users</span>
              <p className="ml-6 mt-1">Follow other users and build your network.</p>
            </li>
            <li className="text-muted-foreground">
              <span className="font-medium text-foreground">Verify engagements</span>
              <p className="ml-6 mt-1">Respond to challenges promptly to maintain trust.</p>
            </li>
          </ol>
        </CardContent>
      </Card>
    </div>
  );
}