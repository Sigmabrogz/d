import React from "react";
import { ChallengeGuide } from "@/components/ChallengeGuide";
import { ChallengeList } from "@/components/challenge/ChallengeList";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Challenge() {
  return (
    <div className="container mx-auto p-4 space-y-6">
      <h1 className="text-3xl font-bold">Challenges</h1>
      
      <Tabs defaultValue="active" className="space-y-6">
        <TabsList>
          <TabsTrigger value="active">Active Challenges</TabsTrigger>
          <TabsTrigger value="guide">How It Works</TabsTrigger>
        </TabsList>

        <TabsContent value="active">
          <ChallengeList />
        </TabsContent>

        <TabsContent value="guide">
          <ChallengeGuide />
        </TabsContent>
      </Tabs>
    </div>
  );
}