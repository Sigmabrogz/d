import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { AlertCircle, AlertTriangle } from "lucide-react";
import { ChallengeProofModal } from "@/components/ChallengeProofModal";
import { ChallengeGuide } from "@/components/ChallengeGuide";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TotalUsersCard } from "@/components/dashboard/TotalUsersCard";
import { TweetSubmissionForm } from "@/components/dashboard/TweetSubmissionForm";
import { TweetsList } from "@/components/dashboard/TweetsList";
import { InactivityWarning } from "@/components/dashboard/InactivityWarning";

interface Tweet {
  id: string;
  url: string;
  created_at: string;
  engagement_count: number | null;
  profile: {
    username: string | null;
    avatar_url: string | null;
    twitter_handle: string | null;
  } | null;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [tweetUrl, setTweetUrl] = useState("");
  const [tweets, setTweets] = useState<Tweet[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingTweets, setLoadingTweets] = useState(true);
  const [userProfile, setUserProfile] = useState<{ id: string; twitter_handle: string | null; last_activity_warning: string | null }>();
  const [dailySubmissionCount, setDailySubmissionCount] = useState(0);
  const MAX_DAILY_SUBMISSIONS = 4;
  const [showProofModal, setShowProofModal] = useState(false);
  const [selectedChallenge, setSelectedChallenge] = useState<{
    id: string;
    type: "engagement" | "follow";
  } | null>(null);

  useEffect(() => {
    checkAuth();
    fetchUserProfile();
    fetchTweets();
    subscribeToTweets();
  }, []);

  const checkAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate("/");
    }
  };

  const fetchUserProfile = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('id, twitter_handle, last_activity_warning')
        .eq('id', user.id)
        .single();
      setUserProfile(profile || { id: user.id, twitter_handle: null, last_activity_warning: null });
    }
  };

  const fetchTweets = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: tweetsData, error } = await supabase
        .from('tweets')
        .select(`
          id,
          url,
          created_at,
          engagement_count,
          profiles (
            username,
            avatar_url,
            twitter_handle
          )
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedTweets: Tweet[] = tweetsData.map(tweet => ({
        id: tweet.id,
        url: tweet.url,
        created_at: tweet.created_at,
        engagement_count: tweet.engagement_count,
        profile: tweet.profiles
      }));

      setTweets(formattedTweets);
      
      const todayTweets = formattedTweets.filter(tweet => 
        new Date(tweet.created_at).toDateString() === new Date().toDateString()
      );
      setDailySubmissionCount(todayTweets.length);
    } catch (error) {
      console.error('Error fetching tweets:', error);
      toast({
        title: "Error",
        description: "Failed to load tweets",
        variant: "destructive",
      });
    } finally {
      setLoadingTweets(false);
    }
  };

  const validateTweetUrl = (url: string, twitterHandle: string | null): boolean => {
    if (!twitterHandle) {
      return false;
    }

    try {
      const urlObj = new URL(url);
      if (!urlObj.hostname.includes('twitter.com') && !urlObj.hostname.includes('x.com')) {
        return false;
      }

      const pathParts = urlObj.pathname.split('/').filter(part => part);
      const urlHandle = pathParts[0]?.toLowerCase();
      
      return urlHandle === twitterHandle.toLowerCase().replace('@', '');
    } catch {
      return false;
    }
  };

  const handleSubmitTweet = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (dailySubmissionCount >= MAX_DAILY_SUBMISSIONS) {
        toast({
          title: "Daily Limit Reached",
          description: `Free trial users can only submit ${MAX_DAILY_SUBMISSIONS} tweets per day`,
          variant: "destructive",
        });
        return;
      }

      if (!userProfile?.twitter_handle) {
        toast({
          title: "Profile Incomplete",
          description: "Please add your Twitter handle in your profile settings first",
          variant: "destructive",
        });
        return;
      }

      if (!validateTweetUrl(tweetUrl, userProfile.twitter_handle)) {
        toast({
          title: "Invalid URL",
          description: "Please submit only tweets from your own Twitter handle",
          variant: "destructive",
        });
        return;
      }

      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error("User not authenticated");
      }

      const { error } = await supabase
        .from('tweets')
        .insert([
          { url: tweetUrl, user_id: user.id }
        ]);

      if (error) {
        throw error;
      }

      toast({
        title: "Tweet submitted",
        description: "Your tweet has been added to the engagement feed",
      });
      setTweetUrl("");
      fetchTweets();
    } catch (error) {
      console.error('Error submitting tweet:', error);
      toast({
        title: "Error",
        description: "Failed to submit tweet",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const subscribeToTweets = () => {
    const channel = supabase
      .channel('public:tweets')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'tweets' },
        (payload) => {
          console.log('Change received!', payload);
          fetchTweets();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleChallenge = async (tweetId: string) => {
    try {
      const { data: engagement } = await supabase
        .from("engagements")
        .select("*")
        .eq("tweet_id", tweetId)
        .single();

      if (engagement) {
        const { error: updateError } = await supabase
          .from("engagements")
          .update({ challenge_status: "challenged" })
          .eq("id", engagement.id);

        if (updateError) throw updateError;

        const { error: notificationError } = await supabase
          .from("notifications")
          .insert([
            {
              user_id: engagement.user_id,
              type: "challenge",
              message: "Your engagement has been challenged. Please provide proof.",
            },
          ]);

        if (notificationError) throw notificationError;

        toast({
          title: "Challenge Initiated",
          description: "The user will be notified to provide proof of engagement.",
        });
      }
    } catch (error) {
      console.error("Error challenging engagement:", error);
      toast({
        title: "Error",
        description: "Failed to initiate challenge",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto p-4 space-y-6">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      
      <InactivityWarning userProfile={userProfile} />
      
      <Alert className="bg-orange-50 border-orange-200">
        <AlertTriangle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-orange-800">
          Stay active! We're building a community of hustlers. Inactive accounts may be removed to maintain 
          an engaged and vibrant community. Participate regularly by submitting tweets and engaging with others.
        </AlertDescription>
      </Alert>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
        <TotalUsersCard />
      </div>
      
      <Tabs defaultValue="submit" className="space-y-6">
        <TabsList>
          <TabsTrigger value="submit">Submit Tweet</TabsTrigger>
          <TabsTrigger value="guide">How It Works</TabsTrigger>
        </TabsList>

        <TabsContent value="submit" className="space-y-6">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Free trial users can submit up to {MAX_DAILY_SUBMISSIONS} tweets per day. 
              You have submitted {dailySubmissionCount} tweets today.
            </AlertDescription>
          </Alert>
          
          <TweetSubmissionForm
            tweetUrl={tweetUrl}
            loading={loading}
            dailySubmissionCount={dailySubmissionCount}
            MAX_DAILY_SUBMISSIONS={MAX_DAILY_SUBMISSIONS}
            userProfile={userProfile}
            onTweetUrlChange={setTweetUrl}
            onSubmit={handleSubmitTweet}
          />

          <TweetsList
            tweets={tweets}
            loadingTweets={loadingTweets}
            onChallenge={handleChallenge}
          />
        </TabsContent>

        <TabsContent value="guide">
          <ChallengeGuide />
        </TabsContent>
      </Tabs>

      {selectedChallenge && (
        <ChallengeProofModal
          isOpen={showProofModal}
          onClose={() => {
            setShowProofModal(false);
            setSelectedChallenge(null);
          }}
          challengeType={selectedChallenge.type}
          challengeId={selectedChallenge.id}
        />
      )}
    </div>
  );
};

export default Dashboard;
