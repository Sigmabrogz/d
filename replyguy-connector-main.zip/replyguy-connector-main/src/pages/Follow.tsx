import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserCheck, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Database } from "@/integrations/supabase/types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FollowGuide } from "@/components/guides/FollowGuide";

type Profile = Database['public']['Tables']['profiles']['Row'];
type Follow = Database['public']['Tables']['follows']['Row'];

export default function Follow() {
  const { toast } = useToast();
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  useEffect(() => {
    const getCurrentUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setCurrentUserId(user.id);
      }
    };
    getCurrentUser();
  }, []);

  const { data: profiles, isLoading } = useQuery({
    queryKey: ['profiles'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*');
      
      if (error) throw error;
      return data as Profile[];
    },
  });

  const { data: follows, refetch: refetchFollows } = useQuery({
    queryKey: ['follows', currentUserId],
    queryFn: async () => {
      if (!currentUserId) return [];
      const { data, error } = await supabase
        .from('follows')
        .select('*')
        .eq('follower_id', currentUserId);
      
      if (error) throw error;
      return data as Follow[];
    },
    enabled: !!currentUserId,
  });

  const handleFollow = async (profileId: string) => {
    if (!currentUserId) return;

    const { error } = await supabase
      .from('follows')
      .insert({
        follower_id: currentUserId,
        following_id: profileId,
        status: 'completed'
      });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to mark as followed",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Success",
      description: "Marked as followed",
    });
    refetchFollows();
  };

  const handleChallenge = async (profileId: string) => {
    if (!currentUserId) return;

    const { error } = await supabase
      .from('follows')
      .update({ status: 'challenged' })
      .eq('follower_id', currentUserId)
      .eq('following_id', profileId);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to challenge follow",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Challenge Sent",
      description: "The follow has been challenged",
    });
    refetchFollows();
  };

  if (isLoading) {
    return <div className="p-8">Loading...</div>;
  }

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-2xl font-bold mb-6">Follow Users</h1>
      
      <Tabs defaultValue="users" className="space-y-6">
        <TabsList>
          <TabsTrigger value="users">Available Users</TabsTrigger>
          <TabsTrigger value="guide">How It Works</TabsTrigger>
        </TabsList>

        <TabsContent value="users">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {profiles?.filter(profile => profile.id !== currentUserId).map((profile) => {
              const follow = follows?.find(f => f.following_id === profile.id);
              const twitterUrl = profile.twitter_handle ? 
                `https://twitter.com/${profile.twitter_handle}` : 
                null;

              return (
                <Card key={profile.id}>
                  <CardHeader>
                    <CardTitle className="text-lg">
                      {profile.full_name || "Anonymous User"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {twitterUrl ? (
                      <a
                        href={twitterUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:underline mb-4 block"
                      >
                        @{profile.twitter_handle}
                      </a>
                    ) : (
                      <p className="text-gray-500 mb-4">No Twitter handle provided</p>
                    )}

                    <div className="flex gap-2">
                      {!follow ? (
                        <Button
                          onClick={() => handleFollow(profile.id)}
                          className="flex-1"
                        >
                          <UserCheck className="w-4 h-4 mr-2" />
                          Mark as Followed
                        </Button>
                      ) : follow.status === 'completed' ? (
                        <Button
                          variant="outline"
                          onClick={() => handleChallenge(profile.id)}
                          className="flex-1"
                        >
                          <AlertCircle className="w-4 h-4 mr-2" />
                          Challenge Follow
                        </Button>
                      ) : (
                        <Button disabled className="flex-1">
                          {follow.status === 'challenged' ? 'Challenged' : 'Pending'}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="guide">
          <FollowGuide />
        </TabsContent>
      </Tabs>
    </div>
  );
}
