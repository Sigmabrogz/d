import { AuthCard } from "@/components/auth/AuthCard";
import { Logo } from "@/components/ui/logo";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="mb-8">
        <Logo size="lg" />
      </div>
      <AuthCard />
    </div>
  );
};

export default Index;