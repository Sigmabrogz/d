import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface Tweet {
  id: string;
  url: string;
  created_at: string;
  user_id: string;
  engagement_count: number | null;
  profile: {
    username: string | null;
    avatar_url: string | null;
    twitter_handle: string | null;
  } | null;
}

interface Engagement {
  tweet_id: string;
  status: string;
}

export const useTweets = () => {
  const [tweets, setTweets] = useState<Tweet[]>([]);
  const [loading, setLoading] = useState(true);
  const [userEngagements, setUserEngagements] = useState<Engagement[]>([]);
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [userJoinDate, setUserJoinDate] = useState<string | null>(null);

  const fetchCurrentUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      setCurrentUser(user.id);
      const { data: profile } = await supabase
        .from('profiles')
        .select('created_at')
        .eq('id', user.id)
        .single();
      
      if (profile) {
        setUserJoinDate(profile.created_at);
      }
    }
  };

  const fetchUserEngagements = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data: engagements } = await supabase
        .from('engagements')
        .select('tweet_id, status')
        .eq('user_id', user.id);
      
      if (engagements) {
        setUserEngagements(engagements);
        console.info('Engaged tweet IDs:', engagements.map(e => e.tweet_id));
      }
    }
  };

  const fetchTweets = async () => {
    try {
      if (!userJoinDate) return;

      const query = supabase
        .from('tweets')
        .select(`
          id,
          url,
          created_at,
          user_id,
          engagement_count,
          profiles (
            username,
            avatar_url,
            twitter_handle
          )
        `)
        .gte('created_at', userJoinDate)
        .order('created_at', { ascending: false });

      const { data: tweetsData, error } = await query;

      if (error) throw error;

      const formattedTweets: Tweet[] = (tweetsData || []).map(tweet => ({
        id: tweet.id,
        url: tweet.url,
        created_at: tweet.created_at,
        user_id: tweet.user_id,
        engagement_count: tweet.engagement_count,
        profile: tweet.profiles
      }));

      setTweets(formattedTweets);
    } catch (error) {
      console.error('Error fetching tweets:', error);
    } finally {
      setLoading(false);
    }
  };

  const subscribeToUpdates = () => {
    // Subscribe to tweets table changes
    const tweetsChannel = supabase
      .channel('tweets-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'tweets' },
        (payload) => {
          console.log('Tweet update received:', payload);
          fetchTweets();
        }
      )
      .subscribe();

    // Subscribe to engagements table changes
    const engagementsChannel = supabase
      .channel('engagements-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'engagements' },
        (payload) => {
          console.log('Engagement update received:', payload);
          fetchUserEngagements();
          fetchTweets(); // Refresh tweets to get updated engagement counts
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(tweetsChannel);
      supabase.removeChannel(engagementsChannel);
    };
  };

  useEffect(() => {
    fetchCurrentUser();
  }, []);

  useEffect(() => {
    if (userJoinDate) {
      fetchTweets();
      fetchUserEngagements();
      const unsubscribe = subscribeToUpdates();
      return () => {
        unsubscribe();
      };
    }
  }, [userJoinDate]);

  return {
    tweets,
    loading,
    userEngagements,
    currentUser,
    fetchTweets,
    fetchUserEngagements
  };
};