import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client with service role key
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get users who haven't been active in 5 days and haven't been warned
    const { data: usersToWarn } = await supabaseClient
      .rpc('warn_near_inactive_users')

    console.log('Users warned about inactivity:', usersToWarn)

    // Get and delete inactive users (7+ days of inactivity)
    const { data: deletedUsers } = await supabaseClient
      .rpc('delete_inactive_users')

    console.log('Inactive users removed:', deletedUsers)

    return new Response(
      JSON.stringify({ 
        message: 'Inactive user check completed successfully'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )
  } catch (error) {
    console.error('Error in check-inactive-users function:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    )
  }
})